package Pratico;
import javax.swing.JOptionPane;

public class Feira {

    
    public void main(String[] args) {
        
        String objeto = "";
        double compra = 0;
        double venda = 0;
        int opcao;
        String menu = "*************** Programa ***************\n 1 - Compra \n 2 - Calcular \n 3 - Venda";
        
        while (true) {
            opcao = Integer.parseInt(JOptionPane.showInputDialog(null, menu, "Feira", -1));

            if (opcao == 1) {
                objeto = JOptionPane.showInputDialog(null, "Digite o nome do produto", "Feira", -1);
                compra = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o preço", "Feira", -1));
            }
            else if (opcao == 2) {
                if (compra > 20) {
                    venda = compra + compra * 0.30;
                } else 
                venda = compra + compra * 0.45;
            }
    
            else if (opcao == 3) {
                JOptionPane.showMessageDialog(null, "Você deve vender por: "+venda, "Feira", -1);
            }
        }
    }
}
