package Pratico;
import javax.swing.JOptionPane;


public class Programa {
    Classe1 cls = new Classe1();
    Media md = new Media();
    Feira fe = new Feira();
    public int opcao;

    public void menu(){
        String menustr = "*************** Programa ***************\n 1 - Conferir palavra \n 2 - Calcular Média \n 3 - Feira";
    
    while(true) {
        opcao = Integer.parseInt(JOptionPane.showInputDialog(null, menustr, "Menu", -1));

        if (opcao == 1){
            cls.main(null);
        }
        else if (opcao == 2) {
            md.main(null);
        }

        else if (opcao == 3) {
            fe.main(null);
        }
        }
    }

    public static void main(String[] args) {
        Programa rod = new Programa();
        rod.menu();
    }
    
}
