package Pratico;
import javax.swing.JOptionPane;

public class Media {

    public int opcao;
    public float nota1 = 0;
    public float nota2 = 0;
    public float media = 0;
    public String nome;
    public boolean verdade = true;
    public String situacao;

    public void menu(){
                String menustr = "*************** Menu da média ***************\n 1- Ler\n 2- Calcular\n 3- Exibir \n 4 - Sair\n Item";

                while(verdade) {
                    opcao = Integer.parseInt(JOptionPane.showInputDialog(null, menustr, "Programa de media", -1));

                    if(opcao == 1) {
                        nome = JOptionPane.showInputDialog(null, "Digite seu nome: ", "Programa de media", -1);
                        nota1 = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite a nota 1: ", "Programa de media", -1));
                        nota2 = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite a nota 2: ", "Programa de media", -1));
                    }

                    else if (opcao == 2) {
                        media = (nota1 + nota2) /2;
                        JOptionPane.showMessageDialog(null, "Calculado");

                        if (media >= 6) {
                            situacao = "Aprovado";
                        } else
                        situacao = "Reprovado";

                    }
                    else if(opcao == 3) {
                        String saida = String.format("Nome: %s\nNota1: %.2f\nNota2: %.2f\nMedia: %.2f\n\nSituação: %s", nome, nota1, nota2, media, situacao);
                        JOptionPane.showMessageDialog(null,saida,"Boletim",-1);
                    }
                    else if(opcao == 4) {
                        verdade = false;
                    } else
                    JOptionPane.showMessageDialog(null, "Você digitou um número inválido", "ERROR 404", 2);



                }
    }

    public  void main(String[] args) {
        Media m1 = new Media();
        m1.menu();
    }

}
