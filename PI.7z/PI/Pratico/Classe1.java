package Pratico;
import javax.swing.JOptionPane;

public class Classe1 {
    public String opcao1;
    public String opcao2;

    public void Opcoes() {
        opcao1 = JOptionPane.showInputDialog(null,"Digite uma palavra", "Programa Comparação",-1);
        opcao2 = JOptionPane.showInputDialog(null,"Digite outra palavra", "Programa Comparação",-1);

        if(opcao1.equals(opcao2)){
            JOptionPane.showMessageDialog(null, "As palavras são iguias");
        }
        else{
            JOptionPane.showMessageDialog(null, "As palavras são diferentes");
        }

    }

    public void main(String[] args) {
        Classe1 cls = new Classe1();
        cls.Opcoes();
    }
}
